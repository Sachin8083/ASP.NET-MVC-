﻿using PoductMasterForm.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Web;
using System.Reflection;

namespace PoductMasterForm.Repository
{
	public class UserOperation : IUserOperation
	{
		public List<CategoryList> GetCategories()
		{
			List<CategoryList> model = new List<CategoryList>();
			SqlConnection conn = new SqlConnection();
			conn.ConnectionString = ConfigurationManager.ConnectionStrings["SqlConnString"].ToString();
			SqlCommand cmd = new SqlCommand("sp_CategoryList", conn);
			cmd.CommandType = System.Data.CommandType.StoredProcedure;
			conn.Open();
			DataSet ds = new DataSet();
			SqlDataAdapter sda = new SqlDataAdapter(cmd);
			sda.Fill(ds);
			model = Helper.ProjectHelper.ConvertToList<CategoryList>(ds.Tables[0]);
			conn.Close();
			return model;
		}

		public List<ProductList> GetProductList()
		{
			List<ProductList> model = new List<ProductList>();
			SqlConnection conn = new SqlConnection();
			conn.ConnectionString = ConfigurationManager.ConnectionStrings["SqlConnString"].ToString();
			SqlCommand cmd = new SqlCommand("sp_GetProductList", conn);
			cmd.CommandType = System.Data.CommandType.StoredProcedure;
			conn.Open();
			DataSet ds = new DataSet();
			SqlDataAdapter sda = new SqlDataAdapter(cmd);
			sda.Fill(ds);
			model = Helper.ProjectHelper.ConvertToList<ProductList>(ds.Tables[0]);
			conn.Close();
			return model;
		}

		public int SaveProduct(ProductViewModel model)
		{
			int id = 0;
			SqlConnection conn = new SqlConnection();
			conn.ConnectionString = ConfigurationManager.ConnectionStrings["SqlConnString"].ToString();
			SqlCommand cmd = new SqlCommand("sp_InsertProduct", conn);
			cmd.CommandType = System.Data.CommandType.StoredProcedure;
			conn.Open();
			cmd.Parameters.AddWithValue("@Category", model.Category_Name);
			cmd.Parameters.AddWithValue("@Name", model.Name);
			cmd.Parameters.AddWithValue("@Picture", model.PicturePath);
			DataSet ds = new DataSet();
			SqlDataAdapter sda = new SqlDataAdapter(cmd);
			sda.Fill(ds);
			id = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
			conn.Close();
			return id;
		}
		public int DeleteProducts(int[] productIds)
		{
			int id = 0;
			SqlConnection conn = new SqlConnection();
			conn.ConnectionString = ConfigurationManager.ConnectionStrings["SqlConnString"].ToString();
			SqlCommand cmd = new SqlCommand("DeleteProducts", conn);
			cmd.CommandType = System.Data.CommandType.StoredProcedure;
			conn.Open();
			string productIdsString = string.Join(",", productIds);
			cmd.Parameters.AddWithValue("@ProductIds",productIdsString);
			id = cmd.ExecuteNonQuery();
			conn.Close();
			return id;
		}
	}
}