﻿using PoductMasterForm.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.DynamicData;

namespace PoductMasterForm.Repository
{
	internal interface IUserOperation
	{
		List<CategoryList> GetCategories();
		int SaveProduct(ProductViewModel model);
		List<ProductList> GetProductList();
		int DeleteProducts(int[] productIds);
	}
}
