﻿using Newtonsoft.Json;
using OfficeOpenXml;
using PoductMasterForm.Models;
using PoductMasterForm.Repository;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace PoductMasterForm.Controllers
{
	public class ProductController : Controller
	{
		IUserOperation uo = new UserOperation();
		// GET: Product
		public ActionResult Index()
		{
			ProductViewModel model = new ProductViewModel();
			model.categoryLists = uo.GetCategories();
			model.ProductLists = uo.GetProductList();
			return View(model);
		}
		public ActionResult SaveProduct(ProductViewModel model, HttpPostedFileBase picture)
		{
			// Generate a unique file name
			string fileName = Guid.NewGuid().ToString() + Path.GetExtension(picture.FileName);

			// Specify the directory path where you want to save the picture
			string directoryPath = Server.MapPath("~/Uploads");

			// Create the directory if it doesn't exist
			if (!Directory.Exists(directoryPath))
			{
				Directory.CreateDirectory(directoryPath);
			}
			// Specify the file path
			string filePath = Path.Combine(directoryPath, fileName);

			// Save the picture to the specified path
			picture.SaveAs(filePath);

			// Update the model with the file path
			model.PicturePath = "/Uploads/" + fileName;
			var saveproduct = uo.SaveProduct(model);
			return Json(new { success = true }); // Return a JSON response indicating success
		}
		public ActionResult DeleteProduct(int[] productIds)
		{
			uo.DeleteProducts(productIds);
			return Json(new { success = true });
		}
		//[HttpPost]
		//public ActionResult ImportFromExcel(List<List<string>> jsonData)
		//{
		//	string json = null;

		//	if (jsonData != null)
		//	{
		//		json = JsonConvert.SerializeObject(jsonData);
		//	}

		//	using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnString"].ToString()))
		//	{
		//		conn.Open();

		//		foreach (List<string> record in jsonData)
		//		{
		//			// Access the values of each column in the record
		//			int id = Convert.ToInt32(record[0]);
		//			string name = record[1];
		//			string category = record[2];
		//			string picture = record[3];

		//			if (id == 0)
		//			{
		//				using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_Products (Name, Category, Picture,CreateDate) VALUES (@Name, @Category, @Picture,GETDATE())", conn))
		//				{
		//					cmd.Parameters.AddWithValue("@Name", name);
		//					cmd.Parameters.AddWithValue("@Category", category);
		//					cmd.Parameters.AddWithValue("@Picture", picture);
		//					cmd.ExecuteNonQuery();
		//				}
		//			}
		//			else
		//			{
		//				using (SqlCommand cmd = new SqlCommand("UPDATE tbl_Products SET Name = @Name, Category = @Category, Picture = @Picture, CreateDate = GETDATE() WHERE Id = @Id", conn))
		//				{
		//					cmd.Parameters.AddWithValue("@Name", name);
		//					cmd.Parameters.AddWithValue("@Category", category);
		//					cmd.Parameters.AddWithValue("@Picture", picture);
		//					cmd.Parameters.AddWithValue("@Id", id);
		//					cmd.ExecuteNonQuery();
		//				}
		//			}
		//		}
		//	}
		//	return Json(new { success = true });
		//}
		public ActionResult ImportFromExcel(List<List<string>> jsonData)
		{
			if (jsonData != null && jsonData.Count > 0)
			{
				using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnString"].ToString()))
				{
					conn.Open();

					foreach (List<string> record in jsonData)
					{
						if (record.Count >= 4)
						{
							// Access the values of each column in the record
							int id = Convert.ToInt32(record[0]);
							string name = record[1];
							string category = record[2];
							string pictureFileName = record[3];

							if (id == 0)
							{
								// Generate a unique file name for the uploaded picture
								string picture = SavePicture(pictureFileName);

								using (SqlCommand cmd = new SqlCommand("INSERT INTO tbl_Products (Name, Category, Picture, CreateDate) VALUES (@Name, @Category, @Picture, GETDATE())", conn))
								{
									cmd.Parameters.AddWithValue("@Name", name);
									cmd.Parameters.AddWithValue("@Category", category);
									cmd.Parameters.AddWithValue("@Picture", picture);
									cmd.ExecuteNonQuery();
								}
							}
							else
							{
								// Check if a new picture is uploaded
								if (!string.IsNullOrEmpty(pictureFileName))
								{
									// Generate a unique file name for the uploaded picture
									string picture = SavePicture(pictureFileName);

									using (SqlCommand cmd = new SqlCommand("UPDATE tbl_Products SET Name = @Name, Category = @Category, Picture = @Picture, CreateDate = GETDATE() WHERE Id = @Id", conn))
									{
										cmd.Parameters.AddWithValue("@Name", name);
										cmd.Parameters.AddWithValue("@Category", category);
										cmd.Parameters.AddWithValue("@Picture", picture);
										cmd.Parameters.AddWithValue("@Id", id);
										cmd.ExecuteNonQuery();
									}
								}
								else
								{
									using (SqlCommand cmd = new SqlCommand("UPDATE tbl_Products SET Name = @Name, Category = @Category, CreateDate = GETDATE() WHERE Id = @Id", conn))
									{
										cmd.Parameters.AddWithValue("@Name", name);
										cmd.Parameters.AddWithValue("@Category", category);
										cmd.Parameters.AddWithValue("@Id", id);
										cmd.ExecuteNonQuery();
									}
								}
							}
						}
						else
						{
							// Handle invalid record
							// Log the error or perform appropriate actions
						}
					}
				}
			}

			return Json(new { success = true });
		}

		private string SavePicture(string pictureFileName)
		{
			string sourceFilePath = Path.Combine(@"C:\Users\admin\OneDrive\Pictures", pictureFileName);

			if (System.IO.File.Exists(sourceFilePath))
			{
				// Generate a unique file name for the destination picture file
				string destinationFileName = Guid.NewGuid().ToString() + Path.GetExtension(pictureFileName);

				// Construct the destination path
				string destinationFilePath = Path.Combine(Server.MapPath("~/ProductPictures"), destinationFileName);

				// Copy the picture file to the destination path
				System.IO.File.Copy(sourceFilePath, destinationFilePath, true);

				// Return the saved picture file path
				return destinationFilePath;
			}

			return null; // Handle the case where the picture file does not exist
		}







		// Other action methods in the controller

		public FileContentResult ExportData()
		{
			ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

			// Retrieve the data from the database
			DataTable dataTable = GetProductData();

			// Create a new Excel package
			using (ExcelPackage package = new ExcelPackage())
			{
				// Create the worksheet
				ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Products");

				// Set the header row
				int rowIndex = 1;
				foreach (DataColumn column in dataTable.Columns)
				{
					worksheet.Cells[rowIndex, column.Ordinal + 1].Value = column.ColumnName;
				}

				// Set the data rows
				rowIndex++;
				foreach (DataRow row in dataTable.Rows)
				{
					foreach (DataColumn column in dataTable.Columns)
					{
						if (column.ColumnName == "CreateDate")
						{
							var createDate = (DateTime)row[column];
							worksheet.Cells[rowIndex, column.Ordinal + 1].Value = createDate;
							worksheet.Cells[rowIndex, column.Ordinal + 1].Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss";
							worksheet.Column(column.Ordinal + 1).Width = 20;
						}
						else
						{
							worksheet.Cells[rowIndex, column.Ordinal + 1].Value = row[column];
						}
					}
					rowIndex++;
				}

				// Convert the Excel package to bytes
				byte[] fileBytes = package.GetAsByteArray();

				// Set the file name for download
				string fileName = "Products.xlsx";

				// Return the file as a FileContentResult
				return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
			}
		}

		private DataTable GetProductData()
			{
				using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnString"].ToString()))
				{
					conn.Open();

					using (SqlCommand cmd = new SqlCommand("SELECT * FROM tbl_Products", conn))
					{
						DataTable dataTable = new DataTable();
						using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
						{
							adapter.Fill(dataTable);
						}

						return dataTable;
					}
				}
			}
		public ActionResult ExportDataEmail(string recipientEmail)
		{
			ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

			// Retrieve the data from the database
			DataTable dataTable = GetProductData();

			// Create a new Excel package
			using (ExcelPackage package = new ExcelPackage())
			{
				// Create the worksheet
				ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Products");

				// Set the header row
				int rowIndex = 1;
				foreach (DataColumn column in dataTable.Columns)
				{
					worksheet.Cells[rowIndex, column.Ordinal + 1].Value = column.ColumnName;
				}

				// Set the data rows
				rowIndex++;
				foreach (DataRow row in dataTable.Rows)
				{
					foreach (DataColumn column in dataTable.Columns)
					{
						if (column.ColumnName == "CreateDate")
						{
							var createDate = (DateTime)row[column];
							worksheet.Cells[rowIndex, column.Ordinal + 1].Value = createDate;
							worksheet.Cells[rowIndex, column.Ordinal + 1].Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss";
							worksheet.Column(column.Ordinal + 1).Width = 20;
						}
						else
						{
							worksheet.Cells[rowIndex, column.Ordinal + 1].Value = row[column];
						}
					}
					rowIndex++;
				}

				// Convert the Excel package to bytes
				byte[] fileBytes = package.GetAsByteArray();

				// Set the file name for download
				string fileName = "Products.xlsx";
				// Send email with attachment
				SendEmailWithAttachment(fileBytes, fileName,recipientEmail);

				// Return the file as a FileContentResult
				return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
			}
		}

		private void SendEmailWithAttachment(byte[] fileBytes, string fileName, string recipientEmail)
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendLine("Hello, <br/><br/>");
			sb.AppendLine("Thanks for contacting us. We will try to reach you as early as possible.");
			sb.AppendLine("<br/><br/><br/>Thanks,<br/>ShooraTech Team");

			MailMessage message = new MailMessage();
			SmtpClient smtpClient = new SmtpClient();

			message.From = new MailAddress("sachin.s@shooratech.com", "Sachin Kumar Sharma");
			message.To.Add(new MailAddress(recipientEmail));
			message.Subject = "Product Details";
			message.IsBodyHtml = true;
			message.Body = sb.ToString();
			Attachment attachment = new Attachment(new MemoryStream(fileBytes), fileName);
			message.Attachments.Add(attachment);

			smtpClient.Port = 587;
			smtpClient.Host = "smtp.gmail.com";
			smtpClient.EnableSsl = true;
			smtpClient.UseDefaultCredentials = false;
			smtpClient.Credentials = new NetworkCredential("sachin.shooratech@gmail.com", "cocihkgxtezjwqmc");

			smtpClient.Send(message);

		}


	}
}
	