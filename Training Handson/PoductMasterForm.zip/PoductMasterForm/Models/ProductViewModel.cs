﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PoductMasterForm.Models
{
	public class ProductViewModel
	{
        public int Id { get; set; }
        public string Name { get; set; }
        public string PicturePath { get; set; }
        public int Category_Id { get; set; }
        public string Category_Name { get; set; }
        public List<CategoryList>categoryLists { get; set; }
        public List<ProductList>ProductLists { get; set; }
    }
}