﻿using Newtonsoft.Json;
using PopupCurd.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PopupCurd.Controllers
{
    public class HomeController : Controller
    {
        DBModel db = new DBModel();
        public ActionResult Index()
        {
            List<Department> DeptList = db.Departments.ToList();
            ViewBag.ListOfDepartment = new SelectList(DeptList, "DepartmentId", "DepartmentName");
            return View();
        }
        public JsonResult GetStudentList()
        {
            List<StudentViewModel1> stulist = db.Students.Where(x=>x.IsDeleted==false).Select(x=> new StudentViewModel1 {
                StudentId = x.StudentId,
                StudentName = x.StudentName,
                Email = x.Email,
                DepartmentName = x.Department.DepartmentName
            }).ToList();
            return Json(stulist,JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetStudentById(int StudentId)
        {
            Student model = db.Students.Where(x => x.StudentId == StudentId).SingleOrDefault();
            string value = string.Empty;
            value = JsonConvert.SerializeObject(model,Formatting.Indented,new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
            });
            return Json(value, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveDataInDatabase(StudentViewModel1 model)
        {
            var result = false;
            try
            {
                if(model.StudentId>0)
                {
                    Student Stu = db.Students.SingleOrDefault(x=>x.IsDeleted==false &&  x.StudentId==model.StudentId);
                    Stu.StudentName = model.StudentName;
                    Stu.Email = model.Email;
                    Stu.DepartmentId = model.DepartmentId;
                    db.SaveChanges();
                    result = true;
                }
                else
                {
                    Student Stu = new Student();
                    Stu.StudentName=model.StudentName;  
                    Stu.Email = model.Email;
                    Stu.DepartmentId = model.DepartmentId;
                    Stu.IsDeleted = false;
                    db.Students.Add(Stu);
                    db.SaveChanges();
                    result = true;
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return Json(result,JsonRequestBehavior.AllowGet);
        }
        public JsonResult DeleteStudentRecord(int StudentId)
        {
            bool result = false;
            Student Stu = db.Students.SingleOrDefault(x => x.IsDeleted == false && x.StudentId == StudentId);
            if(Stu!=null)
            {
                Stu.IsDeleted = true;
                db.SaveChanges();
                result = true;
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}