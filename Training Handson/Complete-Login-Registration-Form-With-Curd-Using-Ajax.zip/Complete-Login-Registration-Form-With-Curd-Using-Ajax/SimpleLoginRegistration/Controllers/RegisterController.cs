﻿using SimpleLoginRegistration.Models;
using SimpleLoginRegistration.Repo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Services.Description;

namespace SimpleLoginRegistration.Controllers
{
    public class RegisterController : Controller
    {
        private Operations op;
        private CurdOperation cuop;

        // GET: Register
        DBModel db = new DBModel();
        public RegisterController()
        {
            this.op = new Operations(new DBModel());
            this.cuop = new CurdOperation(new DBModel1());
        }

        public ActionResult Index()
        {
            return View();
        }
        public JsonResult SaveData(SiteUser model)
        {
            op.SaveData(model);
            return Json("Registration Successful", JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        //public ActionResult SaveData(SiteUser user)
        //{
        //    op.SaveData(user);
        //    return RedirectToAction("Index");
        //}
        //public JsonResult SaveData(SiteUser model)
        //{
        //    db.SiteUsers.Add(model);
        //    db.SaveChanges();
        //    return Json("Registration Successfull", JsonRequestBehavior.AllowGet);
        //}
        [HttpPost]
        public JsonResult CheckUserEmail(string useremail)
        {
            //Method 1
            //bool result = !db.SiteUsers.ToList().Exists(model=>model.Email.Equals(useremail,StringComparison.CurrentCultureIgnoreCase));
            //return Json(result);
            //Method 2
            //var searchemail = db.siteusers.tolist().exists(x => x.email.equals(useremail, stringcomparison.currentcultureignorecase));
            //if (searchemail != null)
            //{
            //    return json(1);
            //}
            //else
            //{
            //    return json(0);
            //}
            System.Threading.Thread.Sleep(200);
            var SerachEmail = db.SiteUsers.Where(x => x.Email == useremail).FirstOrDefault();
            if (SerachEmail != null)
            {
                return Json(1);
            }
            else 
            {
                return Json(0);
            }
        }

        public JsonResult CheckValidUser(SiteUser model)
        {
            string result = "Fail";
            var dataItem = db.SiteUsers.Where(x=>x.Email == model.Email && x.Password==model.Password).FirstOrDefault();
            if(dataItem != null)
            {
                Session["UserID"] = dataItem.ID.ToString();
                Session["UserName"] = dataItem.Username.ToString();
                result = "Success";
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Login()
        {
            if(Session["UserID"]!=null)
            {
                var DataList = cuop.GetRecords().ToList();
                return View(DataList);
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            return RedirectToAction("Index");
        }
        public ActionResult Insert(int id = 0)
        {
            Record data = new Record();
            if (id == 0)
            {
                ViewBag.Msg1 = "CREATE INFORMATION";
                ViewBag.Msg3 = "Save Record";
            }
            if (id != 0)
            {
                ViewBag.Message = "UPDATE INFORMATION";
                ViewBag.Msg2 = "Update Record";
                var data1 = cuop.GetById(id).FirstOrDefault();
                data.name = data1.name;
                data.mob = data1.mob;
                data.email = data1.email;
                data.dob = data1.dob;
            }
            else
            {

            }
            return View(data);
        }
        [HttpPost]
        public ActionResult Insert(Record r)
        {
            if (r.id > 0)
            {
                cuop.Update(r);
            }
            else
            {
                cuop.Insert(r);
            }
            return RedirectToAction("Login");
        }
        public ActionResult Delete(int id)
        {
            var deldata = cuop.GetById(id).FirstOrDefault();
            return View(deldata);
        }
        [HttpPost]
        public ActionResult Delete(int id, FormCollection fc)
        {
            cuop.Delete(id);
            return RedirectToAction("Login");
        }
        public ActionResult Details(int id)
        {
            var getdetail = cuop.GetById(id).FirstOrDefault();
            var detailDisplay = new Record();
            detailDisplay.name = getdetail.name;
            detailDisplay.mob = getdetail.mob;
            detailDisplay.email = getdetail.email;
            detailDisplay.dob = getdetail.dob;
            return View(detailDisplay);
        }
    }
}