﻿using SimpleLoginRegistration.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace SimpleLoginRegistration.Repo
{
    public class CurdOperation
    {
        private DBModel1 dBModel;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1IOHJIE\SQLEXPRESS;Initial Catalog=Curd;Integrated Security=True");
        public CurdOperation(DBModel1 dBModel)
        {
            this.dBModel = dBModel;
        }
        public void Insert(Record r)
        {
            string msg = " ";
            try
            {
                SqlCommand cmd = new SqlCommand("Insert_Record", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", r.name);
                cmd.Parameters.AddWithValue("@mob", r.mob);
                cmd.Parameters.AddWithValue("@email", r.email);
                cmd.Parameters.AddWithValue("@dob", r.dob);
                if (ConnectionState.Open != ConnectionState.Closed)
                {
                    con.Open();
                }
                int n = cmd.ExecuteNonQuery();
                if (n > 0)
                {
                    msg = "Record Has Successfully Saved";
                }
                else
                {
                    msg = "Record Not Saved";
                }
            }
            catch (Exception e)
            {
                msg = "Record Not Saved";
            }
        }
        public List<Record> GetRecords()
        {
            List<Record> lst = new List<Record>();
            SqlCommand cmd = new SqlCommand("Select_Record", con);
            cmd.CommandType = CommandType.StoredProcedure;
            if (ConnectionState.Closed == con.State)
            {
                con.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                lst.Add(new Record()
                {
                    id = Convert.ToInt32(dr["id"]),
                    name = dr["name"].ToString(),
                    mob = dr["mob"].ToString(),
                    email = dr["email"].ToString(),
                    dob = dr["dob"].ToString(),
                });
            }
            con.Close();
            return lst;
        }
        public List<Record> GetById(int id)
        {
            List<Record> lst = new List<Record>();
            SqlCommand cmd = new SqlCommand("selectbyid3", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            if (ConnectionState.Closed == con.State)
            {
                con.Open();
            }
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                lst.Add(new Record()
                {
                    id = Convert.ToInt32(dr["id"]),
                    name = dr["name"].ToString(),
                    mob = dr["mob"].ToString(),
                    email = dr["email"].ToString(),
                    dob = dr["dob"].ToString(),

                });
            }
            con.Close();
            return lst;
        }
        public bool Update(Record r)
        {
            int id = 0;
            SqlCommand cmd = new SqlCommand("Update_Record", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", r.id);
            cmd.Parameters.AddWithValue("@name", r.name);
            cmd.Parameters.AddWithValue("@mob", r.mob);
            cmd.Parameters.AddWithValue("@email", r.email);
            cmd.Parameters.AddWithValue("@dob", r.dob);
            if (ConnectionState.Open != ConnectionState.Closed)
            {
                con.Open();
            }
            id = cmd.ExecuteNonQuery();
            con.Close();
            if (id > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public void Delete(int id)
        {
            SqlCommand cmd = new SqlCommand("Delete_Record", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", id);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }
}