﻿using SimpleLoginRegistration.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;

namespace SimpleLoginRegistration.Repo
{
    public class Operations
    {
        private DBModel dBModel;
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-1IOHJIE\SQLEXPRESS;Initial Catalog=LoginReg;Integrated Security=True");
        public Operations(DBModel dBModel)
        {
            this.dBModel = dBModel;
        }
        public void SaveData(SiteUser r)
        {
            SqlCommand cmd = new SqlCommand("SaveData", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", r.Username);
            cmd.Parameters.AddWithValue("@email", r.Email);
            cmd.Parameters.AddWithValue("@pass", r.Password);
            cmd.Parameters.AddWithValue("@isvalid", 0);
            if (ConnectionState.Open != ConnectionState.Closed)
            {
                con.Open();
            }
            cmd.ExecuteNonQuery();
        }
        //public string Login(SiteUser r)
        //{
        //    int data;
        //    SqlCommand cmd = new SqlCommand("Userlogin1", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Parameters.AddWithValue ("@Email", r.Email);
        //    cmd.Parameters.AddWithValue("@Password", r.Password);
        //    if(ConnectionState.Open!= ConnectionState.Closed)
        //    {
        //        con.Open();
        //    }
        //    data = cmd.ExecuteNonQuery();
        //    return data.ToString();
        //}
    }
}